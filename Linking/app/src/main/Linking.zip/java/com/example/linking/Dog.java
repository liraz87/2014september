package com.example.linking;

import java.io.Serializable;

/**
 * Created by eladlavi on 12/24/14.
 */
public class Dog implements Serializable {
    private static final long serialVersionUID = 1L;
    int age;
    int dateOfBirth;
}
